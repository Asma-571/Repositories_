package com.yelp.yelpapplication.model

data class Business (
    var number: Int,
    var id: String,
    var name: String,
    var age: Int,
    var designation: String
)